/*
 * ユーザー側の商品一覧画面
 *初期画面では商品一覧を表示できないため、初回時のみ一覧表示ボタンを用いて一覧を表示させる。
 *
 */
package userServlet;

import java.io.IOException;
import java.util.*;

import javax.servlet.ServletException;
import javax.servlet.http.*;

import bean.*;
import dao.*;

public class UserProductListServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		HttpSession session = request.getSession();
		String set = null;
		String error = "";
		String cmd = "";
		Product product = new Product();
		ArrayList<Product> list = new ArrayList<Product>();
		ProductDAO productDaoObj = new ProductDAO();

		try {
			// 文字エンコード
			request.setCharacterEncoding("UTF-8");

			User user = (User) session.getAttribute("user");

			if (user == null) {

				if (session.getAttribute("set") == "login") {
					request.setAttribute("error", "セッション切れの為、一覧画面に戻ります");
					cmd = "user";
					set = null;
					session.setAttribute("set", set);
					request.getRequestDispatcher("/view/error.jsp").forward(request, response);
				}
				set = null;
				session.setAttribute("set", set);

			} else {
				if (user.getAuthority() != 2) {
					set = null;
					session.setAttribute("set", set);
					session.invalidate();
				} else {
					set = "login";
					session.setAttribute("set", set);
				}
			}

			list = productDaoObj.selectAll();

			//一覧を受け取り、発売中の商品のみリストに残す。
			list = productDaoObj.selectAll();
			for ( int i= list.size() - 1 ; i >= 0 ; i--) {
				int on_sale = list.get(i).getOn_sale();
				if(on_sale == 1) {
					list.remove(list.get(i));

				}
			}

			request.setAttribute("list", list);

			request.getRequestDispatcher("view/userProductList.jsp").forward(request, response);

		} catch (Exception e) {
			request.setAttribute("error", "データベースに接続できませんでした。");
			cmd = "user";
			request.getRequestDispatcher("/view/error.jsp").forward(request, response);
		}

	}
}
